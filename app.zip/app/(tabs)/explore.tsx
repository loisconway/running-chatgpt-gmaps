"use client"

import { useEffect, useState } from "react"
import { StyleSheet, TouchableOpacity, FlatList, View, Alert, ActivityIndicator, SafeAreaView } from "react-native"
import { useNavigation } from "@react-navigation/native"
import { ThemedText } from "@/components/ThemedText"
import { ThemedView } from "@/components/ThemedView"
import { type SavedRoute, getSavedRoutes, deleteRoute } from "../services/routeStorage"
import { Map, Navigation, Trash2 } from "lucide-react-native"
import { formatDistanceToNow } from "date-fns"

export default function ExploreScreen() {
  const [savedRoutes, setSavedRoutes] = useState<SavedRoute[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [refreshing, setRefreshing] = useState<boolean>(false)
  const navigation = useNavigation()

  useEffect(() => {
    loadSavedRoutes()
  }, [])

  const loadSavedRoutes = async () => {
    try {
      setLoading(true)
      const routes = await getSavedRoutes()
      setSavedRoutes(routes)
    } catch (error) {
      console.error("Error loading saved routes:", error)
      Alert.alert("Error", "Failed to load saved routes")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const handleRefresh = () => {
    setRefreshing(true)
    loadSavedRoutes()
  }

  const handleDeleteRoute = async (routeId: string) => {
    Alert.alert("Delete Route", "Are you sure you want to delete this route?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            await deleteRoute(routeId)
            setSavedRoutes(savedRoutes.filter((route) => route.id !== routeId))
          } catch (error) {
            console.error("Error deleting route:", error)
            Alert.alert("Error", "Failed to delete route")
          }
        },
      },
    ])
  }

  const handleViewRoute = (route: SavedRoute) => {
    // Navigate to the home tab and pass the route data
    navigation.navigate("index", {
      savedRoute: route,
    })
  }

  const renderEmptyState = () => (
    <ThemedView style={styles.emptyContainer}>
      <Map size={60} color="#ccc" />
      <ThemedText style={styles.emptyTitle}>No Saved Routes</ThemedText>
      <ThemedText style={styles.emptyText}>
        Your saved walking routes will appear here. Go to the Home tab to create and save routes.
      </ThemedText>
    </ThemedView>
  )

  const renderRouteItem = ({ item }: { item: SavedRoute }) => (
    <ThemedView style={styles.routeCard}>
      <View style={styles.routeHeader}>
        <ThemedText style={styles.routeName}>{item.name}</ThemedText>
        <ThemedText style={styles.routeDate}>
          {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
        </ThemedText>
      </View>

      <View style={styles.routeDetails}>
        <View style={styles.locationContainer}>
          <View style={styles.locationMarker}>
            <View style={[styles.marker, styles.originMarker]} />
          </View>
          <ThemedText style={styles.locationText} numberOfLines={1}>
            {item.originName}
          </ThemedText>
        </View>

        <View style={styles.routeSeparator}>
          <View style={styles.routeLine} />
        </View>

        <View style={styles.locationContainer}>
          <View style={styles.locationMarker}>
            <View style={[styles.marker, styles.destinationMarker]} />
          </View>
          <ThemedText style={styles.locationText} numberOfLines={1}>
            {item.destinationName}
          </ThemedText>
        </View>
      </View>

      {item.distance && (
        <View style={styles.distanceBadge}>
          <Navigation size={14} color="#4285F4" />
          <ThemedText style={styles.distanceText}>{item.distance}</ThemedText>
        </View>
      )}

      <View style={styles.routeActions}>
        <TouchableOpacity style={[styles.routeButton, styles.viewButton]} onPress={() => handleViewRoute(item)}>
          <Navigation size={16} color="#fff" />
          <ThemedText style={styles.buttonText}>View</ThemedText>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.routeButton, styles.deleteButton]} onPress={() => handleDeleteRoute(item.id)}>
          <Trash2 size={16} color="#fff" />
          <ThemedText style={styles.buttonText}>Delete</ThemedText>
        </TouchableOpacity>
      </View>
    </ThemedView>
  )

  return (
    <SafeAreaView style={styles.safeArea}>
    <ThemedView style={styles.container}>
      <ThemedView style={styles.header}>
        <ThemedText type="title" style={styles.headerTitle}>
          Saved Routes
        </ThemedText>
      </ThemedView>

      {loading && !refreshing ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4285F4" />
          <ThemedText style={styles.loadingText}>Loading saved routes...</ThemedText>
        </View>
      ) : (
        <FlatList
          data={savedRoutes}
          renderItem={renderRouteItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={renderEmptyState}
          onRefresh={handleRefresh}
          refreshing={refreshing}
        />
      )}
    </ThemedView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
  },
  listContent: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  routeCard: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  routeHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  routeName: {
    fontSize: 18,
    fontWeight: "600",
    flex: 1,
    color: "#09134d"
  },
  routeDate: {
    fontSize: 12,
    color: "#09134d",
  },
  routeDetails: {
    marginBottom: 16,
    color: "black"
  },
  locationContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 4,
  },
  locationMarker: {
    width: 24,
    height: 24,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 8,
  },
  marker: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  originMarker: {
    backgroundColor: "#4CAF50",
  },
  destinationMarker: {
    backgroundColor: "#F44336",
  },
  locationText: {
    fontSize: 14,
    flex: 1,
    color: "#4285F4"
  },
  routeSeparator: {
    paddingLeft: 12,
    height: 20,
    justifyContent: "center",
  },
  routeLine: {
    height: "100%",
    width: 2,
    backgroundColor: "#ddd",
  },
  routeActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  routeButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginLeft: 8,
  },
  viewButton: {
    backgroundColor: "#4285F4",
  },
  deleteButton: {
    backgroundColor: "#F44336",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
    marginLeft: 6,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    textAlign: "center",
    color: "#666",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 12,
    color: "#666",
  },
  distanceBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f0f0f0",
    alignSelf: "flex-start",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    marginBottom: 12,
  },
  distanceText: {
    fontSize: 12,
    color: "#4285F4",
    fontWeight: "600",
    marginLeft: 4,
  },
})

