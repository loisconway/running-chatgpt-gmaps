"use client";

import type React from "react";
import { useEffect, useRef, useState } from "react";
import {
  View,
  StyleSheet,
  Alert,
  Platform,
  Dimensions,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
  TextInput,
  Modal,
} from "react-native";
import MapView from "react-native-maps";
import * as Location from "expo-location";
import "react-native-get-random-values";
import GooglePlacesInput from "./GooglePlacesInput";
import { REACT_APP_GOOGLE_MAPS_API_KEY } from "@/environmentVariables";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import {
  Maximize2,
  ChevronDown,
  Navigation,
  Save,
  X,
} from "lucide-react-native";
import { saveRoute, getSavedRoutes } from "../services/routeStorage";
import MapIOS from "./MapRouteIOS";
import MapRouteWeb from "./MapRouteWeb";

const apiKey = REACT_APP_GOOGLE_MAPS_API_KEY;

const { width, height } = Dimensions.get("window");
const isWeb = Platform.OS === "web";

type LocationType = {
  name?: string;
  placeId?: string;
  latitude: number;
  longitude: number;
};

type RouteResponse = {
  routes: Array<{
    polyline: { encodedPolyline: string };
    legs: Array<{
      startLocation: { latLng: LocationType };
      endLocation: { latLng: LocationType };
      distanceMeters?: number;
    }>;
    viewport: { low: LocationType; high: LocationType };
  }>;
};

type SavedRoute = {
  name: string;
  originName: string;
  destinationName: string;
  originPlaceId: string;
  destinationPlaceId: string;
  originLocation: { latitude: number; longitude: number };
  destinationLocation: { latitude: number; longitude: number };
  polyline: string;
  distance: string;
};

interface MapRouteProps {
  savedRoute?: SavedRoute;
}

const MapRoute: React.FC<MapRouteProps> = ({ savedRoute }) => {
  const [currentLocation, setCurrentLocation] = useState<LocationType | null>(
    null
  );
  const [origin, setOrigin] = useState<LocationType | null>(null);
  const [destination, setDestination] = useState<LocationType | null>(null);
  const [route, setRoute] = useState<LocationType[]>([]);
  const [encodedPolyline, setEncodedPolyline] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);
  const [saveModalVisible, setSaveModalVisible] = useState<boolean>(false);
  const [routeName, setRouteName] = useState<string>("");
  const [savedRoutesCount, setSavedRoutesCount] = useState<number>(0);
  const mapRef = useRef<MapView>(null);
  const [routeDistance, setRouteDistance] = useState<string>("");

  useEffect(() => {
    // Get current location
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        Alert.alert(
          "Permission Denied",
          "Location access is required for the best experience."
        );
        return;
      }

      setLoading(true);
      try {
        const location = await Location.getCurrentPositionAsync({});
        const currentLoc = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };
        setCurrentLocation(currentLoc);

        // Center map on current location
        mapRef.current?.animateToRegion(
          {
            latitude: currentLoc.latitude,
            longitude: currentLoc.longitude,
            latitudeDelta: 0.05,
            longitudeDelta: 0.05,
          },
          1000
        );
      } catch (error) {
        console.error("Error getting location:", error);
        Alert.alert(
          "Location Error",
          "Could not determine your current location."
        );
      } finally {
        setLoading(false);
      }
    })();

    // Check saved routes count
    updateSavedRoutesCount();
  }, []);

  useEffect(() => {
    if (savedRoute) {
      loadSavedRoute(savedRoute);
    }
  }, [savedRoute]);

  const loadSavedRoute = (route: SavedRoute) => {
    // Set origin and destination
    if (route.originPlaceId && route.originName) {
      setOrigin({
        placeId: route.originPlaceId,
        name: route.originName,
        latitude: route.originLocation.latitude,
        longitude: route.originLocation.longitude,
      });
    }

    if (route.destinationPlaceId && route.destinationName) {
      setDestination({
        placeId: route.destinationPlaceId,
        name: route.destinationName,
        latitude: route.destinationLocation.latitude,
        longitude: route.destinationLocation.longitude,
      });
    }

    // Set the polyline and decode it
    if (route.polyline) {
      setEncodedPolyline(route.polyline);
      const decodedPath = decodePolyline(route.polyline);
      setRoute(decodedPath);

      // Set distance if available
      if (route.distance) {
        setRouteDistance(route.distance);
      }

      // Fit map to show the entire route
      if (decodedPath.length > 0) {
        setTimeout(() => {
          mapRef.current?.fitToCoordinates(decodedPath, {
            edgePadding: { top: 80, right: 50, bottom: 80, left: 50 },
            animated: true,
          });
        }, 500);
      }
    }
  };

  const updateSavedRoutesCount = async () => {
    try {
      const routes = await getSavedRoutes();
      setSavedRoutesCount(routes.length);
    } catch (error) {
      console.error("Error getting saved routes count:", error);
    }
  };

  const requestRoute = async () => {
    if (!origin?.placeId || !destination?.placeId) {
      Alert.alert(
        "Missing Information",
        "Please set both origin and destination locations."
      );
      return;
    }

    setLoading(true);
    try {
      const reqBody = {
        origin: {
          placeId: origin.placeId,
        },
        destination: {
          placeId: destination.placeId,
        },
        travelMode: "WALK", // Set travel mode to walking
      };

      const response = await fetch(
        "https://routes.googleapis.com/directions/v2:computeRoutes",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Goog-Api-Key": apiKey,
            "X-Goog-FieldMask": "*",
          },
          body: JSON.stringify(reqBody),
        }
      );

      const data: RouteResponse = await response.json();
      if (data.routes && data.routes.length > 0) {
        const polyline = data.routes[0].polyline.encodedPolyline;
        setEncodedPolyline(polyline);
        const decodedPath = decodePolyline(polyline);
        setRoute(decodedPath);

        // Extract and set distance information
        if (
          data.routes[0].legs &&
          data.routes[0].legs.length > 0 &&
          data.routes[0].legs[0].distanceMeters
        ) {
          const distanceInMeters = data.routes[0].legs[0].distanceMeters;
          if (distanceInMeters < 1000) {
            setRouteDistance(`${distanceInMeters} m`);
          } else {
            const distanceInKm = (distanceInMeters / 1000).toFixed(2);
            setRouteDistance(`${distanceInKm} km`);
          }
        }

        // Fit map to show the entire route
        if (decodedPath.length > 0) {
          mapRef.current?.fitToCoordinates(decodedPath, {
            edgePadding: { top: 80, right: 50, bottom: 80, left: 50 },
            animated: true,
          });
        }
      } else {
        Alert.alert(
          "Route Not Found",
          "No walking route could be found between these locations. Please try different locations."
        );
      }
    } catch (error) {
      console.error(error);
      Alert.alert(
        "Network Error",
        "Failed to fetch walking route. Please check your internet connection and try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const decodePolyline = (encoded: string): LocationType[] => {
    let index = 0,
      lat = 0,
      lng = 0,
      coordinates: LocationType[] = [];
    while (index < encoded.length) {
      let shift = 0,
        result = 0,
        byte;
      do {
        byte = encoded.charCodeAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);
      lat += result & 1 ? ~(result >> 1) : result >> 1;
      shift = 0;
      result = 0;
      do {
        byte = encoded.charCodeAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);
      lng += result & 1 ? ~(result >> 1) : result >> 1;
      coordinates.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
    }
    return coordinates;
  };

  const resetRoute = () => {
    setOrigin(null);
    setDestination(null);
    setRoute([]);
    setEncodedPolyline("");
    setRouteDistance("");

    // Return to current location if available
    if (currentLocation) {
      mapRef.current?.animateToRegion(
        {
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        },
        1000
      );
    }
  };

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  const handleSaveRoute = async () => {
    if (!origin || !destination || !encodedPolyline) {
      Alert.alert("Cannot Save", "Please generate a route first.");
      return;
    }

    if (savedRoutesCount >= 5) {
      Alert.alert(
        "Maximum Routes Reached",
        "You can save up to 5 routes. The oldest route will be replaced.",
        [{ text: "OK", onPress: () => setSaveModalVisible(true) }]
      );
    } else {
      setSaveModalVisible(true);
    }
  };

  const confirmSaveRoute = async () => {
    if (!origin || !destination || !encodedPolyline) return;

    try {
      const name = routeName.trim() || `${origin.name} to ${destination.name}`;

      await saveRoute({
        name,
        originName: origin.name || "",
        destinationName: destination.name || "",
        originPlaceId: origin.placeId || "",
        destinationPlaceId: destination.placeId || "",
        originLocation: {
          latitude: origin.latitude,
          longitude: origin.longitude,
        },
        destinationLocation: {
          latitude: destination.latitude,
          longitude: destination.longitude,
        },
        polyline: encodedPolyline,
        distance: routeDistance,
      });

      setSaveModalVisible(false);
      setRouteName("");
      updateSavedRoutesCount();
      Alert.alert("Success", "Route saved successfully!");
    } catch (error) {
      console.error("Error saving route:", error);
      Alert.alert("Error", "Failed to save route. Please try again.");
    }
  };

  if (isWeb) {
    return (
      <ThemedView style={styles.container}>
        <ThemedText>Map view is not available on web.</ThemedText>
      </ThemedView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ThemedView
        style={[styles.container, isFullScreen && styles.fullScreenContainer]}
      >
        {!isFullScreen && (
          <ThemedView style={styles.inputsSection}>
            <View style={styles.titleContainer}>
              <ThemedText type="title" style={styles.title}>
                Walking Route Planner
              </ThemedText>
            </View>

            <GooglePlacesInput
              location={origin}
              setLocation={setOrigin}
              placeholder="Enter starting point"
              label="Origin"
            />

            <GooglePlacesInput
              location={destination}
              setLocation={setDestination}
              placeholder="Enter destination"
              label="Destination"
            />

            <ThemedView style={styles.buttonContainer}>
              <TouchableOpacity
                style={[styles.button, styles.primaryButton]}
                onPress={requestRoute}
                disabled={loading || !origin || !destination}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <ThemedText style={styles.buttonText}>
                    Get Walking Directions
                  </ThemedText>
                )}
              </TouchableOpacity>

              {(origin || destination || route.length > 0) && (
                <TouchableOpacity
                  style={[styles.button, styles.secondaryButton]}
                  onPress={resetRoute}
                  disabled={loading}
                >
                  <ThemedText style={styles.secondaryButtonText}>
                    Reset
                  </ThemedText>
                </TouchableOpacity>
              )}
            </ThemedView>

            {route.length > 0 && (
              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleSaveRoute}
              >
                <Save size={16} color="#fff" />
                <ThemedText style={styles.saveButtonText}>
                  Save Route
                </ThemedText>
              </TouchableOpacity>
            )}
          </ThemedView>
        )}

        <ThemedView
          style={[
            styles.mapContainer,
            isFullScreen && styles.fullScreenMapContainer,
          ]}
        >
          {Platform.OS === "ios" ? (
            <MapIOS
              route={route}
              currentLocation={currentLocation}
              origin={origin}
              destination={destination}
            />
          ) : (
            <MapRouteWeb route={route} />
          )}

          {loading && (
            <View style={styles.loadingOverlay}>
              <ActivityIndicator size="large" color="#4285F4" />
              <ThemedText style={styles.loadingText}>Loading...</ThemedText>
            </View>
          )}

          {routeDistance && (
            <View
              style={[
                styles.distanceOverlay,
                isFullScreen
                  ? styles.distanceOverlayFullScreen
                  : styles.distanceOverlayNormal,
              ]}
            >
              <ThemedText style={styles.distanceText}>
                <Navigation
                  size={14}
                  color="#fff"
                  style={styles.distanceIcon}
                />{" "}
                {routeDistance}
              </ThemedText>
            </View>
          )}

          {!isFullScreen ? (
            <TouchableOpacity
              style={styles.fullScreenButton}
              onPress={toggleFullScreen}
            >
              <Maximize2 color="#000" size={24} />
            </TouchableOpacity>
          ) : (
            <>
              {/* Exit full-screen button */}
              <TouchableOpacity
                style={styles.exitFullScreenButton}
                onPress={toggleFullScreen}
              >
                <View style={styles.exitButtonContent}>
                  <ChevronDown color="#fff" size={20} />
                  <ThemedText style={styles.exitButtonText}>
                    Exit Full Screen
                  </ThemedText>
                </View>
              </TouchableOpacity>

              {/* Route button in full-screen mode */}
              {origin && destination && (
                <TouchableOpacity
                  style={styles.fullScreenRouteButton}
                  onPress={requestRoute}
                  disabled={loading}
                >
                  {loading ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <View style={styles.routeButtonContent}>
                      <Navigation color="#fff" size={20} />
                      <ThemedText style={styles.fullScreenButtonText}>
                        Get Walking Route
                      </ThemedText>
                    </View>
                  )}
                </TouchableOpacity>
              )}

              {/* Save button in full-screen mode */}
              {route.length > 0 && (
                <TouchableOpacity
                  style={styles.fullScreenSaveButton}
                  onPress={handleSaveRoute}
                >
                  <View style={styles.routeButtonContent}>
                    <Save color="#fff" size={20} />
                    <ThemedText style={styles.fullScreenButtonText}>
                      Save Route
                    </ThemedText>
                  </View>
                </TouchableOpacity>
              )}
            </>
          )}
        </ThemedView>

        {/* Save Route Modal */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={saveModalVisible}
          onRequestClose={() => setSaveModalVisible(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <ThemedText style={styles.modalTitle}>Save Route</ThemedText>
                <TouchableOpacity onPress={() => setSaveModalVisible(false)}>
                  <X size={24} color="#000" />
                </TouchableOpacity>
              </View>

              <ThemedText style={styles.modalLabel}>Route Name</ThemedText>
              <TextInput
                style={styles.modalInput}
                value={routeName}
                onChangeText={setRouteName}
                placeholder={
                  origin && destination
                    ? `${origin.name} to ${destination.name}`
                    : "My Route"
                }
                placeholderTextColor="#999"
              />

              <View style={styles.modalButtonContainer}>
                <TouchableOpacity
                  style={[styles.modalButton, styles.modalCancelButton]}
                  onPress={() => setSaveModalVisible(false)}
                >
                  <ThemedText style={styles.modalCancelButtonText}>
                    Cancel
                  </ThemedText>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.modalSaveButton]}
                  onPress={confirmSaveRoute}
                >
                  <ThemedText style={styles.modalSaveButtonText}>
                    Save
                  </ThemedText>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </ThemedView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 10,
    paddingBottom: 60,
  },
  fullScreenContainer: {
    padding: 0,
  },
  inputsSection: {
    marginBottom: 8,
    maxHeight: 280,
  },
  titleContainer: {
    alignItems: "center",
    marginBottom: 6,
  },
  title: {
    fontSize: 18,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 6,
  },
  button: {
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: "center",
    justifyContent: "center",
    minWidth: 100,
  },
  primaryButton: {
    backgroundColor: "#4285F4",
    flex: 1,
    marginRight: 8,
  },
  secondaryButton: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: "#ccc",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
  },
  secondaryButtonText: {
    fontWeight: "600",
    fontSize: 14,
  },
  saveButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginTop: 8,
  },
  saveButtonText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
    marginLeft: 8,
  },
  mapContainer: {
    flex: 1,
    borderRadius: 12,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#ddd",
  },
  fullScreenMapContainer: {
    borderRadius: 0,
    borderWidth: 0,
    marginBottom: 0,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(255, 255, 255, 0.7)",
    alignItems: "center",
    justifyContent: "center",
  },
  loadingText: {
    marginTop: 8,
    fontSize: 16,
  },
  fullScreenButton: {
    position: "absolute",
    top: 16,
    right: 16,
    backgroundColor: "white",
    borderRadius: 8,
    padding: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 10,
  },
  exitFullScreenButton: {
    position: "absolute",
    top: 16,
    left: 0,
    right: 0,
    alignItems: "center",
    zIndex: 10,
  },
  exitButtonContent: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  exitButtonText: {
    color: "#fff",
    fontWeight: "600",
    marginLeft: 8,
  },
  fullScreenRouteButton: {
    position: "absolute",
    bottom: 30,
    right: 16,
    backgroundColor: "#4285F4",
    borderRadius: 24,
    paddingVertical: 12,
    paddingHorizontal: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 10,
  },
  fullScreenSaveButton: {
    position: "absolute",
    bottom: 30,
    left: 16,
    backgroundColor: "#4CAF50",
    borderRadius: 24,
    paddingVertical: 12,
    paddingHorizontal: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 10,
  },
  routeButtonContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  fullScreenButtonText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 16,
    marginLeft: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "80%",
    backgroundColor: "white",
    borderRadius: 12,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "600",
  },
  modalLabel: {
    fontSize: 14,
    marginBottom: 8,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 20,
  },
  modalButtonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  modalButton: {
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    minWidth: 100,
    alignItems: "center",
  },
  modalCancelButton: {
    backgroundColor: "#f0f0f0",
    marginRight: 8,
  },
  modalSaveButton: {
    backgroundColor: "#4CAF50",
  },
  modalCancelButtonText: {
    fontWeight: "600",
  },
  modalSaveButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  distanceOverlay: {
    position: "absolute",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 12,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 5,
  },
  distanceOverlayNormal: {
    top: 16,
    left: 16,
  },
  distanceOverlayFullScreen: {
    top: 70,
    left: 16,
  },
  distanceText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
    flexDirection: "row",
    alignItems: "center",
  },
  distanceIcon: {
    marginRight: 4,
  },
});

export default MapRoute;
